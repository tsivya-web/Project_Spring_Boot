package com.example.demo.Task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/tasks")
@Validated
public class TaskController {

    private final TaskService taskService;

    /**
     * Constructor-based dependency injection for the TaskService.
     * @param taskService the service handling business logic for tasks
     */
    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    /**
     * Create a new task.
     * Uses @Valid to validate the incoming Task object based on annotations in Task class.
     * @param task the task to create
     * @return the created task with HTTP 201 Created status
     */
    @PostMapping
    public ResponseEntity<Task> createTask(@RequestBody @Valid Task task) {
        Task createdTask = taskService.addTask(task);
        return new ResponseEntity<>(createdTask, HttpStatus.CREATED);
    }

    /**
     * Get all tasks.
     * @return list of all tasks with HTTP 200 OK
     */
    @GetMapping
    public ResponseEntity<List<Task>> getAllTasks() {
        List<Task> tasks = taskService.getAllTasks();
        return ResponseEntity.ok(tasks);
    }

    /**
     * Get a task by its ID.
     * @param id the ID of the task to retrieve
     * @return the found task with HTTP 200 OK
     */
    @GetMapping("/{id}")
    public ResponseEntity<Task> getTaskById(@PathVariable int id) {
        Task task = taskService.findTaskById(id);
        return ResponseEntity.ok(task);
    }

    /**
     * Mark a task as completed by its ID.
     * @param id the ID of the task to mark as completed
     * @return HTTP 204 No Content on success
     */
    @PutMapping("/{id}/complete")
    public ResponseEntity<Void> markTaskAsCompleted(@PathVariable int id) {
        taskService.markTaskAsCompleted(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Delete a task by its ID.
     * @param id the ID of the task to delete
     * @return HTTP 204 No Content on success
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTask(@PathVariable int id) {
        taskService.deleteTask(id);
        return ResponseEntity.noContent().build();
    }
}
