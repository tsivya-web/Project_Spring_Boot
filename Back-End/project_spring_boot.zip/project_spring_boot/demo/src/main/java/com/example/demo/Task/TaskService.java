package com.example.demo.Task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
    private final TaskRepository taskRepository;

    /**
     * Constructor-based dependency injection for the TaskRepository.
     * @param taskRepository the repository handling task storage
     */

    @Autowired
    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    /**
     * Adds a new task.
     *
     * @param task the task to add
     * @return the added task
     * @throws IllegalArgumentException if the task is null
     */

    public Task addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }
        return taskRepository.addTask(task);
    }

    /**
     * Retrieves all tasks.
     *
     * @return list of all tasks
     */
    public List<Task> getAllTasks() {
        return taskRepository.getAllTasks();
    }


    /**
     * Finds a task by its ID.
     *
     * @param id the ID of the task
     * @return the found task
     * @throws IllegalArgumentException if no task with the given ID is found
     */
    public Task findTaskById(int id) {
        return taskRepository.findTaskById(id)
                .orElseThrow(() -> new IllegalArgumentException("Task with ID " + id + " not found"));
    }


    /**
     * Marks a task as completed.
     *
     * @param id the ID of the task to mark
     * @throws IllegalArgumentException if the task is not found
     */
    public void markTaskAsCompleted(int id) {
        taskRepository.markTaskAsCompleted(id);
    }

    /**
     * Deletes a task by its ID.
     *
     * @param id the ID of the task to delete
     * @throws IllegalArgumentException if the task is not found
     */
    public void deleteTask(int id) {
        try {
            taskRepository.deleteTask(id);
        } catch (IllegalArgumentException e) {
            System.out.println("Task not found: " + e.getMessage());
        }
    }
}












