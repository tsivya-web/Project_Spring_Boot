package com.example.demo;

import com.example.demo.Task.Task;
import com.example.demo.Task.TaskRepository;
import com.example.demo.Task.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@SpringBootApplication
public class DemoApplication implements CommandLineRunner {
public final TaskService taskService;
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
	@Autowired
	public DemoApplication(TaskService taskService) {
		this.taskService = taskService;
	}

   @Override
	public void run(String[]args){
	   System.out.println("== Adding tasks ==");
	  Task t1=	this.taskService.addTask(new Task("project","to start the project",false));
	   System.out.println(t1);
	  Task t2=this.taskService.addTask(new Task("clean","to clean my room",false));
	   System.out.println(t2);
	   Task t3=	this.taskService.addTask(new Task("a","to start the project",false));
	   System.out.println(t3);


	   System.out.println("\n== All tasks ==");
	   this.taskService.getAllTasks().forEach(System.out::println);

	   System.out.println("\n== Marking task 1 as completed ==");
	   this.taskService.markTaskAsCompleted(1);

	   System.out.println("\n== Tasks after marking complete ==");
	   this.taskService.getAllTasks().forEach(System.out::println);

	   System.out.println("\n== Deleting task 3 ==");
	   this.taskService.deleteTask(3);

	   System.out.println("\n== Tasks after deletion ==");
	   this.taskService.getAllTasks().forEach(System.out::println);

	   System.out.println("\n== Trying to mark non-existing task 4 as complete ==");
	   this.taskService.deleteTask(4);
   }

}
