package com.example.demo.Task;

import org.springframework.stereotype.Repository;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;


@Repository
public class TaskRepository  {

    // Thread-safe list to store tasks
    private final List<Task> tasks = Collections.synchronizedList(new ArrayList<>());
    private final AtomicInteger idGenerator = new AtomicInteger(1);



    /**
     * Adds a new task to the repository.
     *
     * @param task the task to be added
     * @return the added task
     * @throws IllegalArgumentException if the task is null
     */
    public Task addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }
        task.setId(idGenerator.getAndIncrement());
        tasks.add(task);

        return task;
    }




    /**
     * Retrieves all tasks.
     *
     * @return a copy of the list of all tasks
     */
    public List<Task> getAllTasks() {
        return new ArrayList<>(tasks); // Return a copy to avoid exposing internal list
    }




    /**
     * Finds a task by its ID.
     *
     * @param id the task ID
     * @return an Optional containing the task if found, otherwise empty
     */
    public Optional<Task> findTaskById(int id) {
        return tasks.stream()
                .filter(task -> task.getId() == id)
                .findFirst();
    }



    /**
     * Marks a task as completed by its ID.
     *
     * @param id the task ID
     * @throws IllegalArgumentException if the task is not found
     */
    public void markTaskAsCompleted(int id) {
        Optional<Task> taskOpt = findTaskById(id);
        if (taskOpt.isPresent()) {
            taskOpt.get().setCompleted(true);
        } else {
            throw new IllegalArgumentException("Task with ID " + id + " not found");
        }
    }



    /**
     * Deletes a task by its ID.
     *
     * @param id the task ID
     * @throws IllegalArgumentException if the task is not found
     */
    public void deleteTask(int id) {
        boolean removed = tasks.removeIf(task -> task.getId() == id);
        if (!removed) {
         System.out.println("Task with ID " + id + " not found");
        }
    }



}
